#include"isdiv3.h"

bool isDiv(int input, int divisor)
{
	if(input % divisor == 0)
		return true;

	return false;
}