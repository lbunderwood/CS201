#include<iostream>


#ifndef ISDIV3_H
#define ISDIV3_H

bool isDiv(int input, int divisor);

#endif